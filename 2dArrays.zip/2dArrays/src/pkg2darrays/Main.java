/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg2darrays;

/**
 *
 * @author emeris
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int[][] thing = {
            {90,87,76},
            {76,100,57},
            {64,57,91,45},
            {15,0,0,49,58},
            {26},
            {65,76,79}
        };
        
        for(int on = 0; on < thing.length; on++){
            for(int al = 0; al < thing[on].length; al++){
                System.out.print(thing[on][al]+"\t");
            }
            System.out.println();
        }
    }
    
}
