/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab1gui;
import java.awt.*;
import javax.swing.*;

/**
 *
 * @author USER
 */
public class Lab1GUI extends JFrame {

    private JButton LoadButton;
    private JButton ExitButton;
    private JList<String> myList;
    private DefaultListModel<String> listModel;

    private String[] people = {"Jackson", "Pauline", "Tshepo", "Solomon", "Kutlwano", "Musa", "Otlotleng", "Madume", "Belinda", "Reitumetse"};

    public Lab1GUI(){
        setTitle("My First GUI Class");
        setSize(400,300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        listModel = new DefaultListModel<>();
        myList = new JList<>(listModel);
        
        myList.setBorder(BorderFactory.createLineBorder(Color.cyan,6));

        LoadButton = new JButton("Load Data");
        ExitButton = new JButton("Home Time");
        
        ExitButton.setBackground(Color.magenta);
        LoadButton.setBackground(Color.green);

        add(ExitButton);
        add(LoadButton);
        add(new JScrollPane(myList));

        LoadButton.addActionListener(e-> {
            listModel.clear(); 
            for(String ppl:people){
                listModel.addElement(ppl);
                
                try{
                    Thread.sleep(1000);
                }
                catch(InterruptedException s){
                    s.printStackTrace();
                }
                
                JOptionPane.showMessageDialog(null, ppl + " loaded.");
            }
        });
        
        ExitButton.addActionListener(e-> {
            System.exit(0);
        });
        
        setLocationRelativeTo(null); 
        setVisible(true);
   }
        
    public static void main(String[] args) {       
        new Lab1GUI();
    }
    
}
