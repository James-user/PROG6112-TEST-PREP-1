package lab2gui;
import javax.swing.*;
import java.awt.*;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Lab2GUI extends JFrame{

    private ArrayList<Students> studentArray;
    
    private JTextField nameText;
    private JTextField surnameText;
    private JTextField ageText;
    private JTextField courseText;
    private JTextField resultText;
    
    private DefaultListModel<Students> myList;
    private JList<Students> studentList;
    
    public Lab2GUI(){
        studentArray = new ArrayList<>();
        
        setTitle("Student System");
        setSize(600,400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        JTabbedPane tabs = new JTabbedPane();
        
        tabs.add("Add Students", createAddStudentTab());
        tabs.add("View Students", createViewStudentTab());
        
        add(tabs);
        setVisible(true);
    }
    
    private JPanel createAddStudentTab(){
        JPanel panel = new JPanel(new GridLayout(6,2,10,10));
        
        JLabel nameLabel = new JLabel("Student Name");
        nameText = new JTextField();
        
        JLabel surnameLabel = new JLabel("Student Surname");
        surnameText = new JTextField();
        
        JLabel ageLabel = new JLabel("Student Age");
        ageText = new JTextField();
        
        JLabel courseLabel = new JLabel("Student Course");
        courseText = new JTextField();
        
        JLabel resultLabel = new JLabel("Student Result");
        resultText = new JTextField();
        
        JButton addButton = new JButton("Add Student");
        
        panel.add(nameLabel);
        panel.add(nameText);
        
        panel.add(surnameLabel);
        panel.add(surnameText);
        
        panel.add(ageLabel);
        panel.add(ageText);
        
        panel.add(courseLabel);
        panel.add(courseText);
        
        panel.add(resultLabel);
        panel.add(resultText);
        
        panel.add(addButton);
        
        addButton.addActionListener(e-> {
            try{
                String sName = nameText.getText();
                String sSurname = surnameText.getText();
                int sAge = Integer.parseInt(ageText.getText());
                String sCourse = courseText.getText();
                double sResult = Double.parseDouble(resultText.getText());
                
                Students std = new Students(sName, sSurname, sAge, sCourse, sResult);
                
                studentArray.add(std);
                JOptionPane.showMessageDialog(this, sName + " " + sSurname + " has been added.");
                
                nameText.setText("");
                surnameText.setText("");
                ageText.setText("");
                courseText.setText("");
                resultText.setText("");
            }
            catch(NumberFormatException ex){
                JOptionPane.showMessageDialog(this, "Please Enter Correct Age");
            }
        });
            
        JButton saveButton = new JButton("Save to file");
        
        saveButton.addActionListener(e-> {
            try{
                FileWriter writer = new FileWriter("students.txt");
                
                for(Students student : studentArray){
                    writer.write("Name: " + student.getStudentName() + "\n");
                    writer.write("Surname: " + student.getStudentSurname() + "\n");
                    writer.write("Age: " + student.getStudentAge() + "\n");
                    writer.write("Course: " + student.getStudentCourse() + "\n");
                    writer.write("Result: " + student.getStudentResult() + "\n");
                }
                
                writer.close();
                
                JOptionPane.showMessageDialog(this, "Students saved successfully!");
            }
            catch(IOException ex){
                JOptionPane.showMessageDialog(this, "Error! Error! Does not compute!");
            }
        });

        panel.add(saveButton);
        
        return panel;
    }
    
    private JPanel createViewStudentTab(){
        JPanel pll = new JPanel(new BorderLayout());
        myList = new DefaultListModel();
        studentList = new JList<>(myList);
        
        studentList.setBorder(BorderFactory.createLineBorder(Color.magenta, 6));
        
        JButton loadStudents = new JButton("Display Students");
        
        loadStudents.addActionListener(e-> {
           myList.clear();
           for(Students ss : studentArray){
               myList.addElement(ss);
           }
        });
        
        pll.add(new JScrollPane(studentList),BorderLayout.CENTER);
        pll.add(loadStudents, BorderLayout.SOUTH);
        
        return pll;
    }
            
    
    public static void main(String[] args) {
        new Lab2GUI();
    }
    
}
