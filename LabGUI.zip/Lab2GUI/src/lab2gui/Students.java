/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab2gui;

/**
 *
 * @author USER
 */
public class Students {
    private String name;
    private String surname;
    private int age;
    private String course;
    private double result;
    
    public Students(String nm, String sn, int ag, String cs, double rt){
        this.name = nm;
        this.surname = sn;
        this.age = ag;
        this.course = cs;
        this.result = rt;
    }
    
    public String getStudentName(){
        return name;
    }
    
    public String getStudentSurname(){
        return surname;
    }
    
    public int getStudentAge(){
        return age;
    }
    
    public String getStudentCourse(){
        return course;
    }
    
    public double getStudentResult(){
        return result;
    }
    
    @Override
    public String toString(){
        return name + "\t" + surname;
    }
}
