/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sars;

/**
 *
 * @author USER
 */
public class Company {
    public int cID;
    public String cName;
    public String cLocation;
    
    public Company(int id, String cn, String loc){
        cID = id;
        cName = cn;
        cLocation = loc;
    }
    
    public int getCompanyID(){
        return cID;
    }
    
    public String getCompanyName(){
        return cName;
    }
    
    public String getCompanyLocation(){
        return cLocation;
    }
}
