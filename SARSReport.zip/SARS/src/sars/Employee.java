/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sars;
import java.time.LocalDate;

/**
 *
 * @author USER
 */
public class Employee {
    public int eID;
    public String eName;
    public String eSurname;
    public String eAddress;
    public String cName;
    public LocalDate startDate;
    public LocalDate endDate;
    
    public Employee (int ed, String en, String sr,String eADD, String cN, LocalDate eD, LocalDate sD){
        this.eID = ed;
        this.eName = en;
        this.eSurname = sr;
        this.eAddress = eADD;
        this.cName = cN;
        this.endDate = eD;
        this.startDate = sD;
    }
    
    public Employee (int ed, String en, String cN, LocalDate eD, LocalDate sD){
       this.eID = ed;
       this.eName = en;
       this.cName = cN;
       this.startDate = sD;
       this.endDate = eD;
    }
     
     public Employee (int ed, String en, String sr){
     this.eID = ed;
     this.eName = en;
     this.eSurname = sr;
    }
}
