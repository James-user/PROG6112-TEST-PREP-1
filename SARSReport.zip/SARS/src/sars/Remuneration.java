/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sars;
import java.time.LocalDate;

/**
 *
 * @author USER
 */
public class Remuneration extends Employee{
    public double hourlyRate;
    public double workHours;

    public Remuneration(int eid, String en, String cn, LocalDate sD, LocalDate eD, double hr, double wh){
        super(eid, en, cn, sD, eD);
        this.hourlyRate = hr;
        this.workHours = wh;
    }
    
    public double calcSal (int hours){
        workHours = 40;
        hourlyRate = 100;
        double fullPay, overTime;
        
        if(hours > workHours){
            overTime = ((hours - workHours)*(hourlyRate*1.5));
            fullPay = (overTime + (workHours*hourlyRate));
        }
        else{
            fullPay = hours*hourlyRate;
        }
        return fullPay;
    }
}
