/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sars;
import java.util.ArrayList;
import java.util.Scanner;
import java.time.LocalDate;
import java.time.Month;


/**
 *
 * @author USER
 */
public class SARS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        
        ArrayList<Company> comp = new ArrayList();
        ArrayList<Employee> emp = new ArrayList();
        ArrayList<Remuneration> rem = new ArrayList(); 
        
        Company cc = new Company(111, "Cell C", "Sandton");
        Company vc = new Company(134, "Vodacom", "Midrand");
        Company tl = new Company(233, "Telkom", "Centurion");
        
        comp.add(tl);
        comp.add(cc);
        comp.add(vc);
        
        Employee mk = new Employee(64, "Musa", "Kau");
        Employee tk = new Employee(21, "Tebogo", "Kau");
        Employee mt = new Employee(64, "Morena", "Tshepo");
        
        emp.add(mk);
        emp.add(tk);
        emp.add(mt);
        
        
        //(int eid, String en, String sr, String eAdd, String cn, LocalDate sD, LocalDate eD, double hr, double wh)
        rem.add(new Remuneration (mk.eID, mk.eName, cc.cName, LocalDate.of(2026,04,05),LocalDate.of(2026,10,28), 100, 43));
                
        rem.add(new Remuneration (tk.eID, tk.eName, tl.cName, LocalDate.of(2026,01,01),LocalDate.of(2026,06,8), 120, 67));

        rem.add(new Remuneration (mk.eID, mk.eName, vc.cName, LocalDate.of(2025,10,01),LocalDate.of(2026,04,01), 200, 50));
        
        rem.add(new Remuneration (mt.eID, mt.eName, cc.cName, LocalDate.of(2026, 02, 04), LocalDate.of(2026, 06, 20), 60.5, 20));
        
        
    }
}
