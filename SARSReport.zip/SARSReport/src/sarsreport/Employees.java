/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sarsreport;

/**
 *
 * @author emeris
 */
public class Employees implements Person{
    public int eID;
    public String eName;
    public double eSalary;
    
    public Employees(int id, String name, double sal){
        eID = id;
        eName = name;
        eSalary = sal;
    }
    
    @Override
    public String getEmpDetails(){
        return eID + "," + eName + "," + eSalary;
    }
    
    @Override
    public String toString(){
        return "ID: " + eID + "Name: " + eName + "Salary: " + eSalary;
    }
  
}
