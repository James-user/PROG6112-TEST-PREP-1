/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sarsreport;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author emeris
 */
public class SARSReport {

    private static final String DEFAULT_FILE = "students.csv";
    private static final double PASS_MARK = 50.0;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Path file = Paths.get(args.length > 0 ? args[0] : DEFAULT_FILE);

        try {
            List<Student> students = readStudents(file);
            runMenu(students, new Scanner(System.in));
        } catch (IOException | NumberFormatException e) {
            System.out.println("Could not read student records: " + e.getMessage());
        }
    }

    private static List<Student> readStudents(Path file) throws IOException {
        List<Student> students = new ArrayList<>();

        try (BufferedReader reader = Files.newBufferedReader(file)) {
            String line;
            boolean header = true;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) {
                    continue;
                }
                if (header) {
                    header = false;
                    continue;
                }

                String[] fields = line.split(",", -1);
                if (fields.length != 5) {
                    throw new IOException("Invalid record: " + line);
                }
                students.add(new Student(
                        fields[0].trim(),
                        fields[1].trim(),
                        fields[2].trim(),
                        Integer.parseInt(fields[3].trim()),
                        Double.parseDouble(fields[4].trim())));
            }
        }
        return students;
    }

    private static void runMenu(List<Student> students, Scanner scanner) {
        int choice;
        do {
            System.out.println("\nStudent Records Management System");
            System.out.println("1. Display all student records");
            System.out.println("2. Search by Student ID");
            System.out.println("3. Display students by course");
            System.out.println("4. Display students who have passed");
            System.out.println("5. Display statistics");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");

            if (!scanner.hasNextInt()) {
                System.out.println("Please enter a number from the menu.");
                scanner.nextLine();
                choice = -1;
                continue;
            }
            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1 -> displayStudents(students);
                case 2 -> searchById(students, scanner);
                case 3 -> searchByCourse(students, scanner);
                case 4 -> displayPassed(students);
                case 5 -> displayStatistics(students);
                case 0 -> System.out.println("Goodbye.");
                default -> System.out.println("Invalid choice.");
            }
        } while (choice != 0);
    }

    private static void displayStudents(List<Student> students) {
        if (students.isEmpty()) {
            System.out.println("No student records found.");
            return;
        }
        System.out.printf("%-12s %-20s %-25s %-6s %-6s%n", "Student ID", "Name", "Course", "Year", "Mark");
        for (Student student : students) {
            System.out.println(student);
        }
    }

    private static void searchById(List<Student> students, Scanner scanner) {
        System.out.print("Enter Student ID: ");
        String id = scanner.nextLine().trim();
        students.stream()
                .filter(student -> student.getStudentId().equalsIgnoreCase(id))
                .findFirst()
                .ifPresentOrElse(System.out::println, () -> System.out.println("Student not found."));
    }

    private static void searchByCourse(List<Student> students, Scanner scanner) {
        System.out.print("Enter course: ");
        String course = scanner.nextLine().trim();
        List<Student> matches = students.stream()
                .filter(student -> student.getCourse().equalsIgnoreCase(course))
                .toList();
        displayStudents(matches);
    }

    private static void displayPassed(List<Student> students) {
        displayStudents(students.stream()
                .filter(student -> student.getMark() >= PASS_MARK)
                .toList());
    }

    private static void displayStatistics(List<Student> students) {
        if (students.isEmpty()) {
            System.out.println("No statistics available.");
            return;
        }
        double highest = students.stream().mapToDouble(Student::getMark).max().orElse(0);
        double lowest = students.stream().mapToDouble(Student::getMark).min().orElse(0);
        double average = students.stream().mapToDouble(Student::getMark).average().orElse(0);
        System.out.println("Total students: " + students.size());
        System.out.printf("Highest mark: %.2f%nLowest mark: %.2f%nAverage mark: %.2f%n",
                highest, lowest, average);
    }
}
