package sarsreport;

public class Student {

    private final String studentId;
    private final String name;
    private final String course;
    private final int year;
    private final double mark;

    public Student(String studentId, String name, String course, int year, double mark) {
        this.studentId = studentId;
        this.name = name;
        this.course = course;
        this.year = year;
        this.mark = mark;
    }

    public String getStudentId() {
        return studentId;
    }

    public String getName() {
        return name;
    }

    public String getCourse() {
        return course;
    }

    public int getYear() {
        return year;
    }

    public double getMark() {
        return mark;
    }

    @Override
    public String toString() {
        return String.format("%-12s %-20s %-25s %-6d %.2f", studentId, name, course, year, mark);
    }
}