/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cardealer;
import java.util.ArrayList;

/**
 *
 * @author emeris
 */
public class CarDealer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        ArrayList<Cars> cr = new ArrayList();
        
        Cars cr1 = new Cars ("BMW", "320I", 2014);
        
        cr1.features.add("USB-C");
        cr1.features.add("Radio");
        
        cr.add(cr1);
        
        Cars cr2 = new Cars ("Merc", "C63", 2010);
        
        cr2.features.add("Radio");
        cr2.features.add("Home-Plug");
        cr2.features.add("Heated Seats");
        cr2.features.add("Sunroof");
        
        cr.add(cr2);
        
        for(Cars c:cr){
            System.out.println("******************");
            System.out.println("Car Name: " + c.Cname);
            System.out.println("Car Model: " + c.Cmodel);
            System.out.println("Car Year: " + c.year);
            
            System.out.println("Features for " + c.Cname + ":");
            
            for(String ft:c.features){
                System.out.println("\t---" + ft);
            }
            
            System.out.println("******************");
            System.out.println("\n-----Next Car-----\n");
        }
    }
    
}
