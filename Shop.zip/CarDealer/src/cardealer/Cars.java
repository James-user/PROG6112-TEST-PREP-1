/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cardealer;
import java.util.ArrayList;

/**
 *
 * @author emeris
 */
public class Cars {
    String Cname;
    String Cmodel;
    int year;
    
    ArrayList<String> features = new ArrayList();
    
    public Cars(String cn, String ml, int yr){
        Cname = cn;
        Cmodel = ml;
        year = yr;
    }
}
