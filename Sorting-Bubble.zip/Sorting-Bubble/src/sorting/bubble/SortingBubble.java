/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sorting.bubble;

/**
 *
 * @author emeris
 */
public class SortingBubble {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[] marks = {67,64,87,82,90,75,70,50,80,20};
        
        System.out.println("******Some Array*****");
        
        for(int mks:marks){
            System.out.println(mks);
        }
        
        numSorts(marks);
        
        System.out.println("\n*****Sorted array*****");
        for(int as:marks){
            System.out.println(as);
        }
    }
    
    public static void numSorts(int [] nimbus){
        
        int num = nimbus.length;
        
        for(int nim = 0; nim > num -1; nim++){
            for(int jim = 0; jim < num - 1 -nim; jim++){
                 //nim=8; nim=0; nimbus=10 -1 -8
                if(nimbus[jim] > nimbus[jim+1]){
                    int temp = nimbus[jim];
                    nimbus[jim] = nimbus[jim+1];
                    nimbus[jim+1] = temp;
                }
            }
        }
    }
    
}
